-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2023 at 03:11 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web2db`
--

-- --------------------------------------------------------

--
-- Table structure for table `auction`
--

CREATE TABLE `auction` (
  `auction_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `category_id` int(11) NOT NULL,
  `endDate` varchar(100) DEFAULT NULL,
  `current_bid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auction`
--

INSERT INTO `auction` (`auction_id`, `title`, `description`, `category_id`, `endDate`, `current_bid`) VALUES
(1, 'Sofa', 'Rarely used sofa 123', 1, '2023-03-14T20:34', NULL),
(3, 'pant', 'very good pantdadasd', 3, '', NULL),
(4, 'Messi jercy', 'messi worldcup jercy', 4, '2022-12-30', '1233$'),
(5, 'Handiplast', '1000 piece of handiplast', 5, '2022-12-30', '12$'),
(6, 'Dozer', 'heaavy equipment toy', 6, '2022-12-20', '23$'),
(7, 'Honda cb 350', ' very new bike ', 7, '2022-12-20', '2300$'),
(8, 'Samsung A10', ' like New phone', 2, '2022-12-23', '200$'),
(9, 'Flower Pot', 'New flower pot for you interior garden ', 1, '2022-12-28', '7$'),
(10, 'Doublle Dacker bed', ' New bed ,not used ', 1, '2022-12-20', '600$'),
(11, 'Speaker', ' heavy bass speaker ', 2, '2022-12-20', '100$'),
(12, 'sfdsfsfs', 'sdfsfsdsdf', 7, NULL, NULL),
(13, 'sdfsfsdf', 'xzfsfds', 4, '2023-03-15T19:15', '2233');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `name`) VALUES
(1, 'Home & Garden'),
(2, 'Electronics'),
(3, 'Fashion'),
(4, 'Sport'),
(5, 'Health'),
(6, 'Toys'),
(7, 'Motors'),
(8, 'More'),
(11, 'kath');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `review_id` int(11) NOT NULL,
  `addReview` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `auction_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`review_id`, `addReview`, `date`, `user_id`, `auction_id`) VALUES
(1, 'This sofa is very good', '2022-11-30', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `typeofUser` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `password`, `typeofUser`) VALUES
(1, 'AdminA', 'admina@gmail.com', 'AdminA', 'admin'),
(2, 'AdminB', 'adminb@gmail.com', 'AdminB', 'admin'),
(3, 'UserA', 'usera@gmail.com', 'f89608cfdcecd0f0a8c95cd43e7a5b17fdf89fcf', 'user'),
(4, 'UserB', 'userb@gmail.com', '287f917a7b5c0c1f7cae7b0c8904bdfbae867394', 'user'),
(5, 'Aaditya Bogati', 'aaditya.bogati21@my.northampton.ac.uk', '$2y$10$UdHSmCiRIO6H93AjxdpqCu7wvQjTzf5ObamagDhVfuLObSsdU2YJu', 'user'),
(6, 'Aadi Bog', 'bog@gmail.com', '$2y$10$cWRkVrf.TABEcLVA2HYM6evtM6f/kw3GhXEGffO0HsPYM2aaQDjVW', 'user'),
(7, 'abc', 'abc@gmail.com', '$2y$10$acEpDJcpsnXDNnWdguWxkeFgmBJRXGIQ4aTGOKtD3Sg0P0QvEhWny', 'user'),
(8, 'abc', 'abc@gmail.com', '$2y$10$ZW5W4fSNa4cmATUtS5pgVOEA2N98XfJ7rzLViKGNBjOnX0NFA3x4i', 'user'),
(9, 'bcd', 'bcd@gmail.com', '$2y$10$QZkpzsArep/mGDlHUoORKumw4boSBTPn0GGJUJ5/GpbKZETvgaThe', 'user'),
(10, 'AdminC', 'adminc@gmail.com', 'AdminC', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auction`
--
ALTER TABLE `auction`
  ADD PRIMARY KEY (`auction_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `auction_id` (`auction_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auction`
--
ALTER TABLE `auction`
  MODIFY `auction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auction`
--
ALTER TABLE `auction`
  ADD CONSTRAINT `auction_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`);

--
-- Constraints for table `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `review_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `review_ibfk_2` FOREIGN KEY (`auction_id`) REFERENCES `auction` (`auction_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
