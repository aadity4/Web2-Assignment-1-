<?php
session_start();
session_unset();
session_destroy();
//used header to link two pages.
// header('location:loginpage.php');
echo "<script>window.location.href = 'loginpage.php';</script>";
?>