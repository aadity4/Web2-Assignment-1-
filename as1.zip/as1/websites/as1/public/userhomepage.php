<?php
include 'connect.php';
include 'head.php';
?>

 <!DOCTYPE html>
 
 	<main>
	 <a href="addAuction.php" style="border:solid;padding: 10px;font-size: x-large;background-color: aquamarine;margin: 90px;">Post Your Auction</a>
     <a href="viewauction.php" style="border:solid;padding: 10px;font-size: x-large;background-color: antiquewhite;" >View  Auctions</a></h1>
 		<article>
 			<h1>Latest Auctions</h1>
 			<div class="container">
 				<?php 
				//to display latest 10 auction tot the user's home page:
                        $auction = $pdo->prepare("SELECT * FROM auction LIMIT 10");
                        $auction->execute();
                     
                foreach($auction as $i=> $item){?>

 				<h3><?php echo($item['title']) ?></h3>
 				<em>End Date: <?php echo (date('Y-m-d'))?></em>
 				<p>Auction created by <a href="#">User.Name</a></p>
 				<p><?php echo(substr($item['description'],0,150)) ; ?>...</p>

 				<a href="auctionpage.php?auction_id=<?php echo $item['auction_id']; ?>">More</a>
 				<p class="price">Current bid: <?php echo($item['current_bid'])?></p>
 			</div>
 			<?php
				}
					?>
</main>
<h1>

 			<footer>
			 <a class="more productList" href="logout.php" style="font-size: larger;margin-top: 10%;">Logout </a>
 			
 				&copy; ibuy 2019
 			</footer>
 	
 </body>

 </html>