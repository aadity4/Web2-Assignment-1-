<!DOCTYPE html>
<html>

<head>
    <title>ibuy Auctiiiiiions</title>
    <link rel="stylesheet" href="ibuy.css" />
</head>

<body>
    <header>
        <h1><span class="i">i</span><span class="b">b</span><span class="u">u</span><span class="y">y</span></h1>

       

    </header>
    <nav>
        <ul>
        <?php 
            
            // to get category table from database
            // code referenced from https://stackoverflow.com/questions/40275695/get-data-from-category-with-php-mysql#:~:text=Php%20code%3A,row%5B%22cat_id%22%5D.
                    $category = $pdo->prepare("SELECT * FROM category");
                      //executes a prepared statement
                    $category->execute();
                    //The foreach loop iterates through each key/value pair in an array and is only compatible with arrays.
                    foreach($category as $item){?>

        <li><a class="categoryLink" href="categorypage.php"><?php echo ($item['name']);?> </a></li>
        <?php
                    }
                    ?>
    </ul>
</nav>
<img src="banners/1.jpg" alt="Banner" />