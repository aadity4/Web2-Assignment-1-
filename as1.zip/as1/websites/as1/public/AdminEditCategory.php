<?php
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Prepare SQL query to update category by name
    $stmt = $pdo->prepare("UPDATE category SET name=:newname WHERE name=:name");

    // Execute the query with the provided category name
    $name = $_POST['name'];
    $newname = $_POST['newname'];
    if ($stmt->execute(['name' => $name, 'newname' => $newname])) {
        echo '<script> alert("Category updated"); </script>';
    } else {
        echo '<script> alert("Error ! Try Again"); </script>';
    }
}
?>

<?php include 'head.php'; ?>

<article>
    <div>
        <form method="POST" action="">
            <div>
                <h1>Edit Category</h1>
            </div>
            <div>
                <label>Category Name</label>
                <input type="text" placeholder="Enter Category Name" name="name" required>
                <label>New Category Name</label>
                <input type="text" placeholder="Enter New Category Name" name="newname" required>
                <input type="submit" class="submit" value="Edit">
            </div>
        </form>
    </div>
</article>
<a class="more productList" href="adminhomepage.php">Home</a>
<footer>
    &copy; ibuy 2019
</footer>
</main>
</body>
</html>
