<?php
include 'connect.php';
include 'head.php';
if (isset($_POST['submit'])) {
    $title=$_POST['title'];
    $descri=$_POST['description'];
    $catid=$_POST['categorynam'];
    $enddate=$_POST['endDate'];
    $currentbid=$_POST['currentBid'];
    $auction_id = $_POST['auction_id'];
    
    $stmt = $pdo->prepare("UPDATE auction SET title=?, description=?, category_id=?, endDate=?, current_bid=? WHERE auction_id=?");
    $stmt->execute([$title, $descri, $catid, $enddate, $currentbid, $auction_id]);
    
    // header("Location: viewauction.php");
    echo "<script>window.location.href = 'viewauction.php';</script>";
    exit();
}

if (isset($_GET['id'])) {
    $auction_id = $_GET['id'];
    $auction = $pdo->prepare("SELECT * FROM auction WHERE auction_id=?");
    $auction->execute([$auction_id]);
    $item = $auction->fetch();
} else {
    // header("Location: viewauction.php");
    echo "<script>window.location.href = 'viewauction.php';</script>";
    exit();
}
?>
<main>
<form action="editauction.php" method="POST">
    <input type="hidden" name="auction_id" value="<?php echo $item['auction_id']; ?>">
    <label>Title:</label>
    <input type="text" placeholder="Enter Auction Title" name="title" required value="<?php echo $item['title']; ?>">

    <label>Description:</label>
    <textarea name="description" rows="3" cols="4" placeholder="Enter description"><?php echo $item['description']; ?></textarea>

    <label>Category:</label>
    <select name="categorynam">
        <?php 
        $categories = $pdo->prepare("SELECT * FROM category");
        $categories->execute();
        foreach($categories as $category){
            $selected = ($category['category_id'] == $item['category_id']) ? "selected" : "";
            echo'<option value="'.$category['category_id'].'" '.$selected.'>'.$category['name'].'</option>';
        }
        ?>
    </select>

    <label>End Date:</label>
  <input type="datetime-local" name="endDate">
  <input type="submit" name="submit" value="Submit">
</form>
    </main>
