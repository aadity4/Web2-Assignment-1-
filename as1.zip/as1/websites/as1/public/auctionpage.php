<?php
include 'connect.php';
include 'head.php'
?>


<?php
// Retrieve the auction_id parameter from the URL
$auction_id = $_GET['auction_id'];

// Fetch the details of the clicked auction from the database using the auction_id
$auction = $pdo->prepare("SELECT * FROM auction WHERE auction_id = ?");
$auction->execute([$auction_id]);

// Display the details of the clicked auction
$item = $auction->fetch();
?>
<!DOCTYPE html>
<html>


	<h1> Auction</h1>


	<auction class="product">

		<img src="product.png" alt="product name">
		<section class="details">
			<h2>Product Name:<?php echo($item['title']) ?></h2>
			<h3>Product category: <?php echo($item['category_id'])?></h3>
			<em>End Date: <?php echo($item['endDate'])?></em>
			<p class="price">Current bid: <?php echo($item['current_bid'])?></p>
			<p>Auction created by <a href="#">User.Name</a></p>

			<form action="#" class="bid" method='POST'>
				<input type="text" name="bid" placeholder="Enter bid amount" />
				<input type="submit" value="Place bid" />
			</form>
		</section>
		<section class="description">
			<p>
				<?php echo(($item['description'])) ; ?>

		</section>
		<div> <a href="listreview.php">Click to view reviews</a>';</div>

		<div> <a href="addreview.php">	Click to add review</a>';</div>
