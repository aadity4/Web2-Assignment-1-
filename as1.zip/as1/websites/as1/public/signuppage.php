<?php 
//connecting to database
include 'connect.php';
include'head.php';
//to know the https request method:
if ($_SERVER["REQUEST_METHOD"] == "POST") {  //superglobal ,referenced from this website ->https://beamtic.com/php-server-request-method

    //validating password(confirming)
  if($_POST['cpassword']!=$_POST['password']){
    echo '<script> alert("Type same password"); </script>';
  }
  else{
//inserting the given information in users table :
  $stmt = $pdo->prepare("INSERT INTO users SET
                  name= :name,
                  email= :email,
                  password= :password,
                  typeofUser= :typeofUser
                  ");
  $ins=[
    'name' => $_POST['name'],
    'email' => $_POST['email'],
    'password' => password_hash($_POST['password'], PASSWORD_DEFAULT), //USE OF password_has function to store in database
    'typeofUser' => "user"];

    //alter messages on page load after button pressed
  if($stmt->execute($ins)){
    echo '<script> alert("SignUp Successful! Please Login"); </script>';
  }
  else{
    echo '<script> alert("Error! Register again!"); </script>';
  }
}
   
}
?>
<!DOCTYPE html>
<html>


<main>
<h1> Create New Account </h1>
  <form action="" method="POST">
    
      
    
    <div class="form">
      Username:<br>
      <input type="text" placeholder="Enter your name here" name="name" required><br>
      Email:<br>
      <input type="Email" placeholder="Your email here" name="email" required>
      <br>
      Password:<br>
      <input type="password" placeholder="Enter your Password" name="password" required>
      <br>
      Confirm Password:<br>
      <input type="password" placeholder="Confirm your Password" name="cpassword" required><br>
      <input type="submit" class="submit" value="Sign Up"><br>
      <a href="loginpage.php"> Click here to Login</a>
    </div>
  </form>
</main>

</body>

</html>