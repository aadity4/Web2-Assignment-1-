<?php
include 'connect.php';

if (isset($_POST['submit'])) {
	$date = new DateTime();

	$stmt = $pdo->prepare('INSERT INTO review (addReview,user_id , date)
		VALUES (:addReview, :user_id, :date)');

	unset($_POST['submit']);
	$_POST['date'] = $date->format('Y-m-d');

	$stmt->execute($_POST);  

	echo '<p>Review posted</p>';
	echo '<a href="listreview.php">Return to review list</a>';
}
else {
?>
<form action="addreview.php" method="POST">
	<label>Select user</label>
	<select name="user_id">
		<?php
			$stmt = $pdo->prepare('SELECT * FROM users');
			$stmt->execute();

			foreach ($stmt as $row) {
				echo '<option value="' . $row['user_id'] . '">' . $row['name'] . ' '  . '</option>';
			}
		?>
	</select>

	<label>Review</label>
	<textarea name="addReview"></textarea>

	<input type="submit" name="submit" value="add review" />
</form>

<?php
}
?> 
