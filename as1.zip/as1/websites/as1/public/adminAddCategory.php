<?php
include 'connect.php';

//to identify the request method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //to inster into the databse
    $stmt = $pdo->prepare("INSERT INTO category SET name=:name");
    //  alter statement on success / error
    if ($stmt->execute($_POST)) {
        echo '<script> alert("Category added"); </script>';
    } else {
        echo '<script> alert("Error ! Try Again"); </script>';
    }
}
?>
<!DOCTYPE html>
<html>

<?php include 'head.php'; ?>
    <article>
        <div>
            <form method="POST" action="">
                <div>
                    <h1> Add Category </h1>
                </div>
                <div>
                    <label>Category Name:</label>
                    <input type="text" placeholder="Enter Category Name" name="name">

                    <input type="submit" class="submit" value="Add">
                </div>

        </div>
        </form>
        <a class="more productList" href="adminhomepage.php">Home</a>
    </article>
    <footer>
        &copy; ibuy 2019
    </footer>
    </main>
</body>

</html>