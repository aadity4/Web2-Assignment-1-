<?php
include 'connect.php';
include 'head.php';
// Fetch all auctions from the database
$stmt = $pdo->prepare("SELECT * FROM auction");
$stmt->execute();
$auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
	<title>List of Auctions</title>
</head>
<body>
    <main>
	<h1>List of Auctions</h1>
	<table>
		<thead>
			<tr>
				<th>Title</th>
				<th>Description</th>
				<th>Category</th>
				<th>End Date</th>
				<th>Current Bid</th>
				<th>Edit</th>
                <th>Delete</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach($auctions as $auction): ?>
			<tr>
				<td><?php echo $auction['title']; ?></td>
				<td><?php echo $auction['description']; ?></td>
				<td><?php echo $auction['category_id']; ?></td>
				<td><?php echo $auction['endDate']; ?></td>
				<td><?php echo $auction['current_bid']; ?></td>
				<td><a href="editauction.php?id=<?php echo $auction['auction_id']; ?>">Edit</a></td>
				
                <td><a href="deleteauction.php?id=<?php echo $auction['auction_id']; ?>">_/_Delete</a></td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
            </main>
			<a href="userhomepage.php"> Back</a>
</body>
</html>
