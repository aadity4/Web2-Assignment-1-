<?php
 session_start();
if (isset($_SESSION['user'])) {
    session_destroy();
}
include 'connect.php';

//to know the http request method:
  //superglobal ,referenced from this website ->https://beamtic.com/php-server-request-method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //to take user/admin's email and password
    $name = $_POST["email"];
    $password = $_POST["password"];
    //to select and verify email and password stored in databse
    $sql = $pdo->query("select * from users where email='" . $name . "'");
    $sql->execute();
    $row = $sql->fetch();

    if(!$row){
        echo '<script> alert(" Wrong Email or Password! ");  </script>';
    }
    else{
        //to verify if it is admin or user
        if ($name==$row["email"] && password_verify($password, $row['password']) && $row["typeofUser"] == "user") {
            $_SESSION['user'] = $row['id'];
            // header('Location:userhomepage.php');
            echo "<script>window.location.href = 'userhomepage.php';</script>";
        }
     /* I was unable to login to the website as admin while using the code below where password_verify is used to detect the hashed password:   
         elseif ($name==$row["email"] && password_verify($password, $row['password']) && $row["typeofUser"] == "admin") {
            $_SESSION['admin'] = $row['id'];
            header('Location:adminhomepage.php');
            
            So i've  remove the password_verify function and also modified the database for the admin where i had to
             change the hashed password to the normal one. :*/

            elseif ($name==$row["email"] && $password==$row['password'] && $row["typeofUser"] == "admin") {
                $_SESSION['admin'] = $row['id'];
                // header('Location:adminhomepage.php');
                echo "<script>window.location.href = 'adminhomepage.php';</script>";
        } else {
            echo " please enter all the feilds ";
        }
    }
   
}
?>

<!DOCTYPE html>
<html>

<?php include 'head.php'; ?>

    <body>
       
        <main>
        <div class="login">
            <h1>Login</h1>
        </div>
        <form action="#" method="POST">

            <div class="loginform">
                <label for="email">Email<br></label>
                <input type="text" placeholder="Enter Email" name="email"><br>
                <label for="password">Password<br></label>
                <input type="password" placeholder="Enter Password" name="password"><br>
                <input type="submit" class="submit" value="Login"><br>
                <br>
                <a href="signuppage.php">Create new account</a><br>
                <a href="index.php">Home</a>
            </div>
        </form>
</main>
    </body>

</html>