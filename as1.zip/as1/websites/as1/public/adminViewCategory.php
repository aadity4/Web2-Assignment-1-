<?php
include 'connect.php';

// Prepare SQL query to select all categories from the category table
$stmt = $pdo->query("SELECT * FROM category");

// Fetch all the category records and store them in a variable
$categories = $stmt->fetchAll();
?>

<?php include 'head.php'; ?>

<article>
    <div>
        <h1>Category List</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $category) { ?>
                    <tr>
                        <td><?= $category['category_id'] ?></td>
                        <td><?= $category['name'] ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</article>
<a class="more productList" href="adminhomepage.php">Home</a>
<footer>
    &copy; ibuy 2019
</footer>
</main>
</body>
</html>
