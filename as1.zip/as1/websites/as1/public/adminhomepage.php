<?php
include 'connect.php';

?>

<!DOCTYPE html>
<html>

<head>
    <title>ibuy Auctiiiiiions</title>
    <link rel="stylesheet" href="ibuy.css" />
</head>

<body>
    <header>
        <h1><span class="i">i</span><span class="b">b</span><span class="u">u</span><span class="y">y</span></h1>

       

    </header>


<main>

		<h3>Welcome to Admin Home!</h3>
		<li><a href="adminAddCategory.php">Add Category</a></li>
		<li><a href="adminEditCategory.php">Edit Category</a></li>
		<li><a href="adminDeleteCategory.php">Delete Category</a></li>
		
		<?php


// Prepare SQL query to select all categories from the category table
$stmt = $pdo->query("SELECT * FROM category");

// Fetch all the category records and store them in a variable
$categories = $stmt->fetchAll();
?>

<article>
    <div>
        <h1>Category List</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $category) { ?>
                    <tr>
                        <td><?= $category['category_id'] ?></td>
                        <td><?= $category['name'] ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
</main>
	<footer>
		<a class="more productList" href="logout.php">Logout</a>
		&copy; ibuy 2019
	</footer>
	</main>
</body>

</html>