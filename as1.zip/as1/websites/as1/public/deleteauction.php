<?php
include 'connect.php';
include 'head.php';

if (isset($_POST['delete_auction'])) {
  $auction_id = $_POST['auction_id'];

  // execute the delete query
  $delete = $pdo->prepare("DELETE FROM auction WHERE auction_id = :auction_id");
  $delete->bindParam(':auction_id', $auction_id);
  $delete->execute();

  // redirect back to the display auction page
  header('Location: viewauction.php');
  exit();
}
?>
