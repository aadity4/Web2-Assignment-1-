<?php
include 'connect.php';
if (isset($_POST['submit'])) {
    $title = $_POST['title'];
    $descri = $_POST['description'];
    $catid = $_POST['categorynam'];
    $endDate = $_POST['endDate'];
    $current_bid = $_POST['current_bid'];
    
    $stmt = $pdo->prepare("INSERT INTO auction (`title`, `description`, `category_id`, `endDate`, `current_bid`) VALUES (?, ?, ?, ?, ?)");
  
    if ($stmt->execute([$title, $descri, $catid, $endDate, $current_bid])) {
      echo '<script> alert("success! Added"); </script>';
    } else {
      echo '<script> alert("try again"); </script>';
    }
  }
  
  
?>

<?php include 'head.php'; ?>
<h1> Add Your Auction: </h1>
<main>

    <article >
    <div class="form" style="display:grid;">
    <form action="addAuction.php" method="POST">
  
  <label>Title:</label>
  <input type="text" placeholder="Enter Auction Title" name="title" required>
  <label>Description:</label>
  <textarea name="description" rows="3" cols="4" placeholder="Enter description"></textarea>
  <label>Bid Amount:</label>
  <input type="number" placeholder="Enter Bid Amount" name="current_bid" required>
  <label>Category:</label>
  <select name="categorynam">
    <?php 
    $stmt = $pdo->prepare("SELECT * FROM category");
    $stmt->execute();
    foreach($stmt as $item){
      echo '<option value="'.$item['category_id'].'">'.$item['name'].'</option>';
    }
    ?>
  </select>
  <label>End Date:</label>
  <input type="datetime-local" name="endDate">
  <input type="submit" name="submit" value="Submit">
</form>
  </div>


        <div>
            <li><a href="userhomepage.php" class="more auctionLink">Home</a></li>
        </div>
    </article>

    <hr />

    <footer>
        &copy; ibuy 2022
    </footer>
</main>
</body>
</html>
