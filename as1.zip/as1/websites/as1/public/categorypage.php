<?php
include 'connect.php';
include 'head.php';


?>

		<h1> Category listing</h1>

		<ul class="productList">
			<article>
				<?php 
				// to get auctions table from database
				// code referenced from https://stackoverflow.com/questions/40275695/get-data-from-category-with-php-mysql#:~:text=Php%20code%3A,row%5B%22cat_id%22%5D.
                        $auction = $pdo->prepare("SELECT * FROM auction");
						  //executes a prepared statement
                        $auction->execute();
                        //The foreach loop iterates through each key/value pair in an array and is only compatible with arrays.
                        foreach($auction as $item){?>
				<li><a class="productList" href="auctionpage.php"><?php echo ($item['title']);?> </a></li>
                
				<?php
						}
						?>
			</article>
		</ul>
		<li><a href="index.php" class="more auctionLink">Home</a></li>