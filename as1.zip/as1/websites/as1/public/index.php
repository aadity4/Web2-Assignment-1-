<?php
session_start();
include 'connect.php';

?>

<?php include 'head.php'; ?>
	
			<a class="more productList" href="loginpage.php">Login </a>
		</form>
	<main>
		<article>
			<h1>Latest Auctions</h1>
			<div class="container">
				<?php 
                        $auction = $pdo->prepare("SELECT * FROM auction LIMIT 10");
                        $auction->execute();
                        
                foreach($auction as $i=> $item){?>

				<h3><?php echo($item['title']) ?></h3>
				<em>End Date: <?php echo (date('Y-m-d'))?></em>
				<p>Auction created by <a href="#">User.Name</a></p>
				<p><?php echo(substr($item['description'],0,150)) ; ?>...</p>
				<a href="Loginpage.php"> more</a>
				<p class="price">Current bid: <?php echo($item['current_bid'])?></p>
			</div>
			<?php
				}
					?>
			
			<footer>
				&copy; ibuy 2019
			</footer>
	</main>
</body>

</html>