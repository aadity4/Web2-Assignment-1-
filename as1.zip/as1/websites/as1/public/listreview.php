<?php
include 'connect.php';


            $stmt = $pdo->prepare('SELECT * FROM review');

$userQuery = $pdo->prepare('SELECT * FROM users WHERE user_id = :id');

$stmt->execute();

echo '<ul>';
foreach ($stmt as $row) {
	$criteria = [
		'id' => $row['user_id']
	];

	$userQuery->execute($criteria);

	$user = $userQuery->fetch();

	$date = new DateTime($row['date']);

	echo '<li>' . $row['addReview'] . ' posted by 
		<strong>' . $user['name'] . ' ' .  '</strong> 
		on <em>' . $date->format('d/m/Y') . '</em>';

}
echo '</ul>';

echo '<a href="addreview.php">Add your review</a>';
?>
